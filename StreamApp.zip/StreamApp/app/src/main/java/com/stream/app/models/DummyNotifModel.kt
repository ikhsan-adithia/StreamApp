package com.stream.app.models

class DummyNotifModel(val text: String, val time: String)